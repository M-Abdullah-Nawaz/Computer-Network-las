//    task 3

#include <stdio.h>

int main(){
FILE *fp;
FILE* fp1;
char buff;

fp = fopen("input.txt", "r");
fp1 = fopen("output1.txt","w");

while((buff = fgetc(fp)) != EOF){
if( (buff >= 97 && buff <=122) || (buff >= 65 && buff <=90) ){
continue;
}
else
fputc( buff,fp1 );
}
fclose(fp1);
fclose(fp);
return 0;
}
