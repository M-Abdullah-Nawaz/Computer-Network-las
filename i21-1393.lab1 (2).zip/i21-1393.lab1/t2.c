//    task 2

#include <stdio.h>

int main(){
FILE *fp;
FILE* fp1;
char buff;

fp = fopen("input.txt", "r");
fp1 = fopen("output.txt","w");

while((buff = fgetc(fp)) != EOF){
if(buff >= 48 && buff <=57){
fputc( buff,fp1 );
}
}
fclose(fp1);
fclose(fp);
return 0;
}
