//    task 4

#include <stdio.h>
#include<string.h>

int main(){
FILE *fp;
FILE* fp1;
char buff[255];

fp = fopen("input.txt", "r");
fp1 = fopen("output2.txt","w");

while(fscanf(fp,"%s",buff)!= EOF){
int x,temp=0;

for(x=0;x<strlen(buff);x++){
if(buff[x] == 'A'|| buff[x] == 'E' || buff[x] == 'I' || buff[x] == 'O' || buff[x] == 'U' ||
 buff[x] == 'a'|| buff[x] == 'e' || buff[x] == 'i' || buff[x] == 'o' || buff[x] == 'u'){
 temp =1;
 break;
}
}
if(temp ==1){
char c[strlen(buff)];
int end = strlen(buff)-1;
for(int i=0;i<strlen(buff);i++,--end){
c[i] = buff[end];
putc(c[i],fp1);
c[i] = '\0';

fprintf(fp1,"%s",c);


}
}
else{

fprintf(fp1,"%s",buff);
putc(' ',fp1);

}
}



fclose(fp);
fclose(fp1);
return 0;

}
